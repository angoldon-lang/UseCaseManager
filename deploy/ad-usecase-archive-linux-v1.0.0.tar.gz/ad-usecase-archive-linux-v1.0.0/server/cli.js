#!/usr/bin/env node
"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// standalone/server/db.js
var require_db = __commonJS({
  "standalone/server/db.js"(exports2, module2) {
    "use strict";
    var fs2 = require("fs");
    var path2 = require("path");
    var { DatabaseSync } = require("node:sqlite");
    function openDatabase2(dataDir2) {
      fs2.mkdirSync(path2.join(dataDir2, "assets"), { recursive: true });
      const db = new DatabaseSync(path2.join(dataDir2, "usecases.db"));
      db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      role TEXT NOT NULL CHECK (role IN ('admin','editor','reader')),
      password_hash TEXT NOT NULL,
      disabled INTEGER NOT NULL DEFAULT 0,
      created TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      data TEXT NOT NULL,
      version INTEGER NOT NULL DEFAULT 1,
      created TEXT NOT NULL,
      modified TEXT NOT NULL,
      author_name TEXT NOT NULL DEFAULT '',
      author_email TEXT NOT NULL DEFAULT '',
      editor_name TEXT NOT NULL DEFAULT '',
      deleted INTEGER NOT NULL DEFAULT 0,
      deleted_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_cases_deleted ON cases(deleted);
  `);
      return db;
    }
    module2.exports = { openDatabase: openDatabase2 };
  }
});

// standalone/server/auth.js
var require_auth = __commonJS({
  "standalone/server/auth.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var SESSION_HOURS = 12;
    var MIN_PASSWORD = 10;
    function hashPassword(password) {
      const salt = crypto.randomBytes(16);
      const hash = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
      return "scrypt$" + salt.toString("hex") + "$" + hash.toString("hex");
    }
    function verifyPassword(password, stored) {
      const parts = String(stored).split("$");
      if (parts.length !== 3 || parts[0] !== "scrypt") {
        return false;
      }
      const salt = Buffer.from(parts[1], "hex");
      const expected = Buffer.from(parts[2], "hex");
      const actual = crypto.scryptSync(password, salt, expected.length, { N: 16384, r: 8, p: 1 });
      return crypto.timingSafeEqual(actual, expected);
    }
    function checkPasswordPolicy(password) {
      if (typeof password !== "string" || password.length < MIN_PASSWORD) {
        return "La password deve contenere almeno " + MIN_PASSWORD + " caratteri.";
      }
      return null;
    }
    function sha256(text) {
      return crypto.createHash("sha256").update(text).digest("hex");
    }
    function createSession(db, userId) {
      const token = crypto.randomBytes(32).toString("base64url");
      const expires = Date.now() + SESSION_HOURS * 3600 * 1e3;
      db.prepare("DELETE FROM sessions WHERE expires < ?").run(Date.now());
      db.prepare("INSERT INTO sessions (token_hash, user_id, expires) VALUES (?, ?, ?)").run(sha256(token), userId, expires);
      return { token, maxAge: SESSION_HOURS * 3600 };
    }
    function findSessionUser(db, token) {
      if (!token) {
        return null;
      }
      return db.prepare(
        `SELECT u.id, u.username, u.display_name AS displayName, u.email, u.role
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.expires > ? AND u.disabled = 0`
      ).get(sha256(token), Date.now()) || null;
    }
    function destroySession(db, token) {
      if (token) {
        db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
      }
    }
    function permissionsFor(role) {
      const write = role === "admin" || role === "editor";
      return { canAdd: write, canEdit: write, canDelete: write };
    }
    function createThrottle(maxFailures = 5, windowMs = 10 * 60 * 1e3) {
      const failures = /* @__PURE__ */ new Map();
      const prune = (key, now) => (failures.get(key) || []).filter((t) => now - t < windowMs);
      return {
        retryAfter(key) {
          const now = Date.now();
          const list = prune(key, now);
          failures.set(key, list);
          return list.length >= maxFailures ? Math.ceil((list[0] + windowMs - now) / 1e3) : 0;
        },
        fail(key) {
          const now = Date.now();
          const list = prune(key, now);
          list.push(now);
          failures.set(key, list);
        },
        reset(key) {
          failures.delete(key);
        }
      };
    }
    module2.exports = {
      hashPassword,
      verifyPassword,
      checkPasswordPolicy,
      createSession,
      findSessionUser,
      destroySession,
      permissionsFor,
      createThrottle,
      MIN_PASSWORD
    };
  }
});

// standalone/server/cli.js
var fs = require("fs");
var path = require("path");
var readline = require("readline");
var { openDatabase } = require_db();
var auth = require_auth();
var dataDir = path.resolve(process.env.UCM_DATA_DIR || path.join(process.cwd(), "data"));
var [cmd, ...args] = process.argv.slice(2);
function usage() {
  console.log(`Uso: ucm <comando>

  user:list
  user:add <utente> "<Nome visualizzato>" <admin|editor|reader> [email]   (la password viene chiesta)
  user:passwd <utente>
  user:role <utente> <admin|editor|reader>
  user:disable <utente> | user:enable <utente> | user:delete <utente>
  trash:list                 elenca i casi eliminati
  trash:restore <id>         ripristina un caso eliminato
  backup <cartella>          copia database e loghi in <cartella>

Variabile: UCM_DATA_DIR (predefinita ./data). Attuale: ${dataDir}`);
}
function askPassword(prompt) {
  if (process.env.UCM_NEW_PASSWORD) {
    return Promise.resolve(process.env.UCM_NEW_PASSWORD);
  }
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => {
      if (s.includes(prompt)) {
        rl.output.write(s);
      }
    };
    rl.question(prompt, (a) => {
      rl.output.write("\n");
      rl.close();
      resolve(a);
    });
  });
}
(async () => {
  if (!cmd || cmd === "-h" || cmd === "--help") {
    return usage();
  }
  const db = openDatabase(dataDir);
  const need = (n) => {
    if (args.length < n) {
      usage();
      process.exit(2);
    }
  };
  const getUser = (name) => {
    const u = db.prepare("SELECT * FROM users WHERE username = ?").get(name);
    if (!u) {
      console.error("Utente non trovato: " + name);
      process.exit(1);
    }
    return u;
  };
  const roles = ["admin", "editor", "reader"];
  switch (cmd) {
    case "user:list":
      db.prepare("SELECT username, display_name, role, disabled, email FROM users ORDER BY username").all().forEach((u) => console.log([u.username, u.display_name, u.role, u.disabled ? "DISABILITATO" : "attivo", u.email].join("	")));
      break;
    case "user:add": {
      need(3);
      if (!roles.includes(args[2])) {
        console.error("Ruolo non valido.");
        process.exit(2);
      }
      const pw = await askPassword("Password (min " + auth.MIN_PASSWORD + " caratteri): ");
      const problem = auth.checkPasswordPolicy(pw);
      if (problem) {
        console.error(problem);
        process.exit(1);
      }
      db.prepare("INSERT INTO users (username, display_name, email, role, password_hash, created) VALUES (?, ?, ?, ?, ?, ?)").run(args[0], args[1], args[3] || "", args[2], auth.hashPassword(pw), (/* @__PURE__ */ new Date()).toISOString());
      console.log("Utente creato.");
      break;
    }
    case "user:passwd": {
      need(1);
      const u = getUser(args[0]);
      const pw = await askPassword("Nuova password: ");
      const problem = auth.checkPasswordPolicy(pw);
      if (problem) {
        console.error(problem);
        process.exit(1);
      }
      db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(auth.hashPassword(pw), u.id);
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(u.id);
      console.log("Password aggiornata; sessioni attive chiuse.");
      break;
    }
    case "user:role":
      need(2);
      if (!roles.includes(args[1])) {
        console.error("Ruolo non valido.");
        process.exit(2);
      }
      db.prepare("UPDATE users SET role = ? WHERE id = ?").run(args[1], getUser(args[0]).id);
      console.log("Ruolo aggiornato.");
      break;
    case "user:disable":
    case "user:enable": {
      need(1);
      const u = getUser(args[0]);
      db.prepare("UPDATE users SET disabled = ? WHERE id = ?").run(cmd === "user:disable" ? 1 : 0, u.id);
      if (cmd === "user:disable") {
        db.prepare("DELETE FROM sessions WHERE user_id = ?").run(u.id);
      }
      console.log("Fatto.");
      break;
    }
    case "user:delete":
      need(1);
      db.prepare("DELETE FROM users WHERE id = ?").run(getUser(args[0]).id);
      console.log("Utente eliminato.");
      break;
    case "trash:list":
      db.prepare("SELECT id, data, deleted_at FROM cases WHERE deleted = 1 ORDER BY deleted_at DESC").all().forEach((r) => {
        const d = JSON.parse(r.data);
        console.log([r.id, d.cliente, d.nomeProgetto, r.deleted_at].join("	"));
      });
      break;
    case "trash:restore":
      need(1);
      db.prepare("UPDATE cases SET deleted = 0, deleted_at = NULL WHERE id = ?").run(Number(args[0]));
      console.log("Ripristinato (se presente).");
      break;
    case "backup": {
      need(1);
      const dest = path.resolve(args[0]);
      fs.mkdirSync(path.join(dest, "assets"), { recursive: true });
      const target = path.join(dest, "usecases.db");
      fs.rmSync(target, { force: true });
      db.exec("VACUUM INTO '" + target.replace(/'/g, "''") + "'");
      const src = path.join(dataDir, "assets");
      if (fs.existsSync(src)) {
        fs.cpSync(src, path.join(dest, "assets"), { recursive: true });
      }
      console.log("Backup creato in " + dest);
      break;
    }
    default:
      usage();
      process.exit(2);
  }
  db.close();
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
